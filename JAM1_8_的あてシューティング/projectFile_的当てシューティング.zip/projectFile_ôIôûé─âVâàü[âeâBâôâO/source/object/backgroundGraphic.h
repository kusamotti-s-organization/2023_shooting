﻿#pragma once

void BackgroundGraphicInit();
void BackgroundGraphicUpdate();
void BackgroundGraphicDraw();
void BackgroundGraphicDelete();

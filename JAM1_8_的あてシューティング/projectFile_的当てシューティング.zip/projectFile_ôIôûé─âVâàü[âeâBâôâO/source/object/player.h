﻿#pragma once

void PlayerInit();
void PlayerUpdate();
void PlayerDraw();
void PlayerDelete();

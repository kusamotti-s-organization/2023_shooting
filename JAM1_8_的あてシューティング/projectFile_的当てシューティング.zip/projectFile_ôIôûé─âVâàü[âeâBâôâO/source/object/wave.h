﻿#pragma once

void WaveInit();
void WaveUpdate();
void WaveDraw();
void WaveDelete();

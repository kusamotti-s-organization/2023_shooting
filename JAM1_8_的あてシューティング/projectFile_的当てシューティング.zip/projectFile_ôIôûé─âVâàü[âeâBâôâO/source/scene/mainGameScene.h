﻿#pragma once

void MainGameSceneInit();
void MainGameSceneUpdate();
void MainGameSceneDraw();
void MainGameSceneDelete();

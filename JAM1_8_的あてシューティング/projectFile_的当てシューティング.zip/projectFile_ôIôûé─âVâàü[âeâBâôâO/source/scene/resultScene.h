﻿#pragma once

void ResultSceneInit();
void ResultSceneUpdate();
void ResultSceneDraw();
void ResultSceneDelete();

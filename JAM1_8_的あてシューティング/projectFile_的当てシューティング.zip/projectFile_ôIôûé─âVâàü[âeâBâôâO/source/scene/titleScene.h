﻿#pragma once

void TitleSceneInit();
void TitleSceneUpdate();
void TitleSceneDraw();
void TitleSceneDelete();
